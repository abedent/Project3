const express = require("express");
const app = express();
app.set("view engine", "ejs");
let path = require("path");
app.use(express.urlencoded({ extended: true }));

const port = 3000;

// create database connection
const knex = require("knex")({
  client: "pg",
  connection: {
    host: "localhost",
    user: "postgres",
    password: "7431082a",
    database: "MusicLibrary",
    port: 5432,
  },
});

//route for home page
app.get("/", (req, res) => {
  res.render("index");
});

//route for adding a Song form
app.get("/addsong", (req, res) => {
  res.render("addsong");
});

//route for post addsong
app.post("/addsong", (req, res) => {
  let sSongName = req.body.SongName;
  let sArtist = req.body.ArtistID;
  let sYear = req.body.YearReleased;
  console.log(req);
  knex("Songs")
    .insert({
      SongName: sSongName,
      ArtistID: sArtist,
      YearReleased: sYear,
    })
    .then((results) => {
      res.redirect("/displaysongs");
    });
});

//route for editsong form
app.get("/edit/:SongID", (req, res) => {
  knex
    .select()
    .from("Songs")
    .where("SongID", req.params.SongID)
    .then((result) => {
      res.render("editsong", { aSongs: result });
    })
    .catch((err) => {
      console.log(err);
      res.status(500).json({ err });
    });
});

//post for editsong
app.post("/edit/:SongID", (req, res) => {
  knex("Songs")
    .where("SongID", req.params.SongID)
    .update({
      SongName: req.body.SongName,
      ArtistID: req.body.ArtistID,
      YearReleased: req.body.YearReleased,
    })
    .then((result) => {
      res.redirect("/displaysongs");
    });
});

// post for delete a song
app.get("/delete/:SongID", (req, res) => {
  knex("Songs")
    .where("SongID", req.params.SongID)
    .del()
    .then((result) => {
      res.redirect("/displaysongs");
    })
    .catch((err) => {
      console.log(err);
      res.status(500).json({ err });
    });
});

//route to delete all songs and replace with first three
app.post("/deleteAllSongs/", (req, res) => {
  knex("Songs")
    .del()
    .then((result) => {
      knex("Songs")
        .insert(originaldata)
        .then(() => {
          res.redirect("/displaysongs");
        });
    });
});

//route for display songs
app.get("/displaysongs", (req, res) => {
  knex
    .select()
    .from("Songs")
    .then((results) => {
      res.render("displaysongs", { aSongs: results });
    });
});

//start website
app.listen(port, () => console.log("I am running"));
